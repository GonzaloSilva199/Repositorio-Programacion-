﻿using AplicacionEscrito.Datos;
using AplicacionEscritoEntidad;
using System.Collections.Generic;

namespace AplicacionEscrito.Negocio
{
    public class PropiedadNegocio
    {
        private readonly PropiedadesDatos propiedadesDatos = new PropiedadesDatos();

        public List<Propiedad> ObtenerPropiedad()
        {
            return propiedadesDatos.ObtenerPropiedades();
        }

        public bool AgregarPropiedad(Propiedad propiedad)
        {
            return propiedadesDatos.InsertarPropiedad(propiedad);
        }

        public bool ModificarPropiedad(Propiedad propiedad)
        {
            return propiedadesDatos.ModificarPropieadad(propiedad);
        }

        public bool EliminarPropiedad(int id)
        {
            return propiedadesDatos.EliminarPropiedad(id);
        }
    }
}
