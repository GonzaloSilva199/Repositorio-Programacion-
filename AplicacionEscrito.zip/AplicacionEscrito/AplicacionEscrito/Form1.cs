using System;
using System.Windows.Forms;
using AplicacionEscrito.Negocio;
using AplicacionEscritoEntidad;
using System.Diagnostics;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;

namespace AplicacionEscrito
{
    public partial class Form1 : Form
    {
        private readonly PropiedadNegocio propiedadNegocio = new PropiedadNegocio();
        private readonly VentaNegocio ventaNegocio = new VentaNegocio();

        public Form1()
        {
            InitializeComponent();
            CargarDatosPropiedades();
            CargarDatosVentas();
        }

        private void CargarDatosPropiedades()
        {
            dgvPropiedad.DataSource = propiedadNegocio.ObtenerPropiedad();
        }

        private void CargarDatosVentas()
        {
            dgvVentas.DataSource = ventaNegocio.ObtenerVentas();
        }

        private void btnAgregarPropiedad_Click(object sender, EventArgs e)
        {
            var propiedad = new Propiedad
            {
                Id = int.Parse(txtIdPropiedad.Text),
                Tipo = txtTipo.Text,
                Direccion = txtDireccion.Text,
                Precio = int.Parse(txtPrecio.Text),
                Metros_Cuadrados = int.Parse(txtMetrosCuadrados.Text)
            };

            if (propiedadNegocio.AgregarPropiedad(propiedad))
            {
                MessageBox.Show("Propiedad agregado con �xito.");
                CargarDatosPropiedades();
            }
            else
            {
                MessageBox.Show("Error al agregar propieddad.");
            }
        }

        private void btnModificarPropiedad_Click(object sender, EventArgs e)
        {
            var propiedad = new Propiedad
            {
                Id = int.Parse(txtIdPropiedad.Text),
                Tipo = txtTipo.Text,
                Direccion = txtDireccion.Text,
                Precio = int.Parse(txtPrecio.Text),
                Metros_Cuadrados = int.Parse(txtMetrosCuadrados.Text)
            };

            if (propiedadNegocio.ModificarPropiedad(propiedad))
            {
                MessageBox.Show("Propiedad modificado con �xito.");
                CargarDatosPropiedades();
            }
            else
            {
                MessageBox.Show("Error al modificar propiedad.");
            }
        }

        private void btnEliminarPropiedad_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtIdPropiedad.Text);

            if (propiedadNegocio.EliminarPropiedad(id))
            {
                MessageBox.Show("Propiedad eliminado con �xito.");
                CargarDatosPropiedades();
            }
            else
            {
                MessageBox.Show("Error al eliminar propiedead.");
            }
        }

        private void btnAgregarVenta_Click(object sender, EventArgs e)
        {
            var venta = new Venta
            {
                Id_Venta = int.Parse(txtIdVenta.Text),
                Id_Propiedad = int.Parse(txtIdPropiedadVenta.Text),
                Precio = int.Parse(txtPrecioVenta.Text),
                Descuento = int.Parse(txtDescuento.Text),
                IVA = int.Parse(txtIVA.Text),
                Precio_Total = int.Parse(txtPrecioTotal.Text)
            };

            if (ventaNegocio.AgregarVenta(venta))
            {
                MessageBox.Show("Venta agregada con �xito.");
                CargarDatosVentas();
            }
            else
            {
                MessageBox.Show("Error al agregar venta.");
            }
        }

        private void btnModificarVenta_Click(object sender, EventArgs e)
        {
            var venta = new Venta
            {
                Id_Venta = int.Parse(txtIdVenta.Text),
                Id_Propiedad = int.Parse(txtIdPropiedadVenta.Text),
                Precio = int.Parse(txtPrecioVenta.Text),
                Descuento = int.Parse(txtDescuento.Text),
                IVA = int.Parse(txtIVA.Text),
                Precio_Total = int.Parse(txtPrecioTotal.Text)
            };

            if (ventaNegocio.ModificarVenta(venta))
            {
                MessageBox.Show("Venta modificada con �xito.");
                CargarDatosVentas();
            }
            else
            {
                MessageBox.Show("Error al modificar venta.");
            }
        }

        private void btnEliminarVenta_Click(object sender, EventArgs e)
        {
            int id = int.Parse(txtIdVenta.Text);

            if (ventaNegocio.EliminarVenta(id))
            {
                MessageBox.Show("Venta eliminada con �xito.");
                CargarDatosVentas();
            }
            else
            {
                MessageBox.Show("Error al eliminar venta.");
            }
        }

        private void btnImprimirBoleta_Click(object sender, EventArgs e)
        {
            if (dgvVentas.SelectedRows.Count == 0)
            {
                MessageBox.Show("Por favor, seleccione una venta para imprimir la boleta.");
                return;
            }

        
            var selectedRow = dgvVentas.SelectedRows[0];
            int idVenta = Convert.ToInt32(selectedRow.Cells["Id_Venta"].Value);
            int idPropiedad = Convert.ToInt32(selectedRow.Cells["Id_Propiedad"].Value);
            int precio = Convert.ToInt32(selectedRow.Cells["Precio"].Value);
            int descuento = Convert.ToInt32(selectedRow.Cells["Descuento"].Value);
            int iva = Convert.ToInt32(selectedRow.Cells["IVA"].Value);
            int precioTotal = Convert.ToInt32(selectedRow.Cells["Precio_Total"].Value);

            
            string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
            string path = Path.Combine(desktopPath, $"Boleta_Venta_{idVenta}.pdf");

          
            Document doc = new Document(PageSize.A4);
            PdfWriter.GetInstance(doc, new FileStream(path, FileMode.Create));
            doc.Open();

            // Agrega contenido al PDF
            doc.Add(new Paragraph("-------------------"));
            doc.Add(new Paragraph("Boleta de Venta"));
            doc.Add(new Paragraph("-------------------"));
            doc.Add(new Paragraph($"ID Venta: {idVenta}"));
            doc.Add(new Paragraph($"ID Propiedad: {idPropiedad}"));
            doc.Add(new Paragraph($"Precio: {precio}"));
            doc.Add(new Paragraph($"Descuento: {descuento}"));
            doc.Add(new Paragraph($"IVA: {iva}"));
            doc.Add(new Paragraph($"Precio Total: {precioTotal}"));
            doc.Add(new Paragraph("Gracias por su compra"));

        
            doc.Close();

            MessageBox.Show($"Boleta generada con �xito en el escritorio: {path}");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
