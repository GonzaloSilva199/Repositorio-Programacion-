﻿namespace AplicacionEscrito
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvPropiedad;
        private System.Windows.Forms.DataGridView dgvVentas;
        private System.Windows.Forms.TextBox txtIdPropiedad;
        private System.Windows.Forms.TextBox txtTipo;
        private System.Windows.Forms.TextBox txtPrecio;
        private System.Windows.Forms.TextBox txtMetrosCuadrados;
        private System.Windows.Forms.TextBox txtIdVenta;
        private System.Windows.Forms.TextBox txtIdPropiedadVenta;
        private System.Windows.Forms.TextBox txtPrecioVenta;
        private System.Windows.Forms.TextBox txtDescuento;
        private System.Windows.Forms.TextBox txtIVA;
        private System.Windows.Forms.TextBox txtPrecioTotal;
        private System.Windows.Forms.Button btnAgregarElectrodomestico;
        private System.Windows.Forms.Button btnModificarElectrodomestico;
        private System.Windows.Forms.Button btnEliminarElectrodomestico;
        private System.Windows.Forms.Button btnAgregarVenta;
        private System.Windows.Forms.Button btnModificarVenta;
        private System.Windows.Forms.Button btnEliminarVenta;
        private System.Windows.Forms.Button btnImprimirBoleta;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            dgvPropiedad = new DataGridView();
            dgvVentas = new DataGridView();
            txtIdPropiedad = new TextBox();
            txtTipo = new TextBox();
            txtPrecio = new TextBox();
            txtMetrosCuadrados = new TextBox();
            txtIdVenta = new TextBox();
            txtIdPropiedadVenta = new TextBox();
            txtPrecioVenta = new TextBox();
            txtDescuento = new TextBox();
            txtIVA = new TextBox();
            txtPrecioTotal = new TextBox();
            btnAgregarElectrodomestico = new Button();
            btnModificarElectrodomestico = new Button();
            btnEliminarElectrodomestico = new Button();
            btnAgregarVenta = new Button();
            btnModificarVenta = new Button();
            btnEliminarVenta = new Button();
            btnImprimirBoleta = new Button();
            txtDireccion = new TextBox();
            ((System.ComponentModel.ISupportInitialize)dgvPropiedad).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgvVentas).BeginInit();
            SuspendLayout();
            // 
            // dgvPropiedad
            // 
            dgvPropiedad.Location = new Point(20, 20);
            dgvPropiedad.Name = "dgvPropiedad";
            dgvPropiedad.Size = new Size(400, 150);
            dgvPropiedad.TabIndex = 0;
            // 
            // dgvVentas
            // 
            dgvVentas.Location = new Point(20, 300);
            dgvVentas.Name = "dgvVentas";
            dgvVentas.Size = new Size(400, 150);
            dgvVentas.TabIndex = 1;
            // 
            // txtIdPropiedad
            // 
            txtIdPropiedad.Location = new Point(450, 20);
            txtIdPropiedad.Name = "txtIdPropiedad";
            txtIdPropiedad.PlaceholderText = "ID Propiedad";
            txtIdPropiedad.Size = new Size(200, 23);
            txtIdPropiedad.TabIndex = 2;
            // 
            // txtTipo
            // 
            txtTipo.Location = new Point(450, 50);
            txtTipo.Name = "txtTipo";
            txtTipo.PlaceholderText = "Tipo";
            txtTipo.Size = new Size(200, 23);
            txtTipo.TabIndex = 3;
            // 
            // txtPrecio
            // 
            txtPrecio.Location = new Point(450, 118);
            txtPrecio.Name = "txtPrecio";
            txtPrecio.PlaceholderText = "Precio";
            txtPrecio.Size = new Size(200, 23);
            txtPrecio.TabIndex = 4;
            // 
            // txtMetrosCuadrados
            // 
            txtMetrosCuadrados.Location = new Point(450, 147);
            txtMetrosCuadrados.Name = "txtMetrosCuadrados";
            txtMetrosCuadrados.PlaceholderText = "Metros Cudrados";
            txtMetrosCuadrados.Size = new Size(200, 23);
            txtMetrosCuadrados.TabIndex = 5;
            // 
            // txtIdVenta
            // 
            txtIdVenta.Location = new Point(450, 300);
            txtIdVenta.Name = "txtIdVenta";
            txtIdVenta.PlaceholderText = "ID Venta";
            txtIdVenta.Size = new Size(200, 23);
            txtIdVenta.TabIndex = 6;
            // 
            // txtIdPropiedadVenta
            // 
            txtIdPropiedadVenta.Location = new Point(450, 330);
            txtIdPropiedadVenta.Name = "txtIdPropiedadVenta";
            txtIdPropiedadVenta.PlaceholderText = "ID Propiedad";
            txtIdPropiedadVenta.Size = new Size(200, 23);
            txtIdPropiedadVenta.TabIndex = 7;
            // 
            // txtPrecioVenta
            // 
            txtPrecioVenta.Location = new Point(450, 360);
            txtPrecioVenta.Name = "txtPrecioVenta";
            txtPrecioVenta.PlaceholderText = "Precio";
            txtPrecioVenta.Size = new Size(200, 23);
            txtPrecioVenta.TabIndex = 8;
            // 
            // txtDescuento
            // 
            txtDescuento.Location = new Point(450, 390);
            txtDescuento.Name = "txtDescuento";
            txtDescuento.PlaceholderText = "Descuento";
            txtDescuento.Size = new Size(200, 23);
            txtDescuento.TabIndex = 9;
            // 
            // txtIVA
            // 
            txtIVA.Location = new Point(450, 420);
            txtIVA.Name = "txtIVA";
            txtIVA.PlaceholderText = "IVA";
            txtIVA.Size = new Size(200, 23);
            txtIVA.TabIndex = 10;
            // 
            // txtPrecioTotal
            // 
            txtPrecioTotal.Location = new Point(450, 450);
            txtPrecioTotal.Name = "txtPrecioTotal";
            txtPrecioTotal.PlaceholderText = "Precio Total";
            txtPrecioTotal.Size = new Size(200, 23);
            txtPrecioTotal.TabIndex = 11;
            // 
            // btnAgregarElectrodomestico
            // 
            btnAgregarElectrodomestico.Location = new Point(700, 20);
            btnAgregarElectrodomestico.Name = "btnAgregarElectrodomestico";
            btnAgregarElectrodomestico.Size = new Size(150, 30);
            btnAgregarElectrodomestico.TabIndex = 12;
            btnAgregarElectrodomestico.Text = "Agregar Electrodoméstico";
            btnAgregarElectrodomestico.Click += btnAgregarPropiedad_Click;
            // 
            // btnModificarElectrodomestico
            // 
            btnModificarElectrodomestico.Location = new Point(700, 60);
            btnModificarElectrodomestico.Name = "btnModificarElectrodomestico";
            btnModificarElectrodomestico.Size = new Size(150, 30);
            btnModificarElectrodomestico.TabIndex = 13;
            btnModificarElectrodomestico.Text = "Modificar Electrodoméstico";
            btnModificarElectrodomestico.Click += btnModificarPropiedad_Click;
            // 
            // btnEliminarElectrodomestico
            // 
            btnEliminarElectrodomestico.Location = new Point(700, 100);
            btnEliminarElectrodomestico.Name = "btnEliminarElectrodomestico";
            btnEliminarElectrodomestico.Size = new Size(150, 30);
            btnEliminarElectrodomestico.TabIndex = 14;
            btnEliminarElectrodomestico.Text = "Eliminar Electrodoméstico";
            btnEliminarElectrodomestico.Click += btnEliminarPropiedad_Click;
            // 
            // btnAgregarVenta
            // 
            btnAgregarVenta.Location = new Point(700, 300);
            btnAgregarVenta.Name = "btnAgregarVenta";
            btnAgregarVenta.Size = new Size(150, 30);
            btnAgregarVenta.TabIndex = 15;
            btnAgregarVenta.Text = "Agregar Venta";
            btnAgregarVenta.Click += btnAgregarVenta_Click;
            // 
            // btnModificarVenta
            // 
            btnModificarVenta.Location = new Point(700, 340);
            btnModificarVenta.Name = "btnModificarVenta";
            btnModificarVenta.Size = new Size(150, 30);
            btnModificarVenta.TabIndex = 16;
            btnModificarVenta.Text = "Modificar Venta";
            btnModificarVenta.Click += btnModificarVenta_Click;
            // 
            // btnEliminarVenta
            // 
            btnEliminarVenta.Location = new Point(700, 380);
            btnEliminarVenta.Name = "btnEliminarVenta";
            btnEliminarVenta.Size = new Size(150, 30);
            btnEliminarVenta.TabIndex = 17;
            btnEliminarVenta.Text = "Eliminar Venta";
            btnEliminarVenta.Click += btnEliminarVenta_Click;
            // 
            // btnImprimirBoleta
            // 
            btnImprimirBoleta.Location = new Point(700, 420);
            btnImprimirBoleta.Name = "btnImprimirBoleta";
            btnImprimirBoleta.Size = new Size(150, 30);
            btnImprimirBoleta.TabIndex = 18;
            btnImprimirBoleta.Text = "Imprimir Boleta";
            btnImprimirBoleta.Click += btnImprimirBoleta_Click;
            // 
            // txtDireccion
            // 
            txtDireccion.Location = new Point(450, 89);
            txtDireccion.Name = "txtDireccion";
            txtDireccion.PlaceholderText = "Direccion";
            txtDireccion.Size = new Size(200, 23);
            txtDireccion.TabIndex = 19;
            txtDireccion.TextChanged += textBox1_TextChanged;
            // 
            // Form1
            // 
            ClientSize = new Size(1000, 600);
            Controls.Add(txtDireccion);
            Controls.Add(dgvPropiedad);
            Controls.Add(dgvVentas);
            Controls.Add(txtIdPropiedad);
            Controls.Add(txtTipo);
            Controls.Add(txtPrecio);
            Controls.Add(txtMetrosCuadrados);
            Controls.Add(txtIdVenta);
            Controls.Add(txtIdPropiedadVenta);
            Controls.Add(txtPrecioVenta);
            Controls.Add(txtDescuento);
            Controls.Add(txtIVA);
            Controls.Add(txtPrecioTotal);
            Controls.Add(btnAgregarElectrodomestico);
            Controls.Add(btnModificarElectrodomestico);
            Controls.Add(btnEliminarElectrodomestico);
            Controls.Add(btnAgregarVenta);
            Controls.Add(btnModificarVenta);
            Controls.Add(btnEliminarVenta);
            Controls.Add(btnImprimirBoleta);
            Name = "Form1";
            Text = "Gestión de Electrodomésticos y Ventas";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvPropiedad).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgvVentas).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private TextBox txtDireccion;
    }
}
