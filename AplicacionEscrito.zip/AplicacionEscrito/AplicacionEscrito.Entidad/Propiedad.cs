﻿namespace AplicacionEscritoEntidad
{
    public class Propiedad
    {
        public int Id { get; set; }
        public string Tipo { get; set; }
        public string Direccion { get; set; }
        public int Precio { get; set; }
        public int Metros_Cuadrados { get; set; }
    }
}
