﻿using AplicacionEscritoEntidad;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace AplicacionEscrito.Datos
{
    public class PropiedadesDatos
    {
        private readonly string connectionString = "Server=localhost;Database=EscritoPP;Uid=root;Pwd=12345;";

        public List<Propiedad> ObtenerPropiedades()
        {
            var propiedades = new List<Propiedad>();
            using var connection = new MySqlConnection(connectionString);
            connection.Open();
            using var command = new MySqlCommand("SELECT * FROM Propiedades", connection);
            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                var propiedad = new Propiedad
                {
                    Id = reader.GetInt32("Id"),
                    Tipo = reader.GetString("Tipo"),
                    Direccion = reader.GetString("Direccion"),
                    Precio = reader.GetInt32("Precio"),
                    Metros_Cuadrados = reader.GetInt32("Metros_Cuadrados")
                };
                propiedades.Add(propiedad);
            }
            return propiedades;
        }

        public bool InsertarPropiedad(Propiedad propiedad)
        {
            using var connection = new MySqlConnection(connectionString);
            connection.Open();
            using var command = new MySqlCommand("INSERT INTO Propiedades (Id, Tipo, Direccion, Precio, Metros_Cuadrados) VALUES (@Id, @Tipo, @Direccion, @Precio, @Metros_Cuadrados)", connection);
            command.Parameters.AddWithValue("@Id", propiedad.Id);
            command.Parameters.AddWithValue("@Tipo", propiedad.Tipo);
            command.Parameters.AddWithValue("@Direccion", propiedad.Direccion);
            command.Parameters.AddWithValue("@Precio", propiedad.Precio);
            command.Parameters.AddWithValue("@Metros_Cuadrados", propiedad.Metros_Cuadrados);
            return command.ExecuteNonQuery() > 0;
        }

        public bool ModificarPropieadad(Propiedad propiedad)
        {
            using var connection = new MySqlConnection(connectionString);
            connection.Open();
            using var command = new MySqlCommand("UPDATE Propiedades SET Tipo = @Tipo, Direccion = @Direccionn, Precio = @Precio, Metros_Cuadrados = @Metros_Cuadrados WHERE Id = @Id", connection);
            command.Parameters.AddWithValue("@Id", propiedad.Id);
            command.Parameters.AddWithValue("@Tipo", propiedad.Tipo);
            command.Parameters.AddWithValue("@Direccion", propiedad.Direccion);
            command.Parameters.AddWithValue("@Precio", propiedad.Precio);
            command.Parameters.AddWithValue("@Metros_Cuadrados", propiedad.Metros_Cuadrados);
            return command.ExecuteNonQuery() > 0;
        }

        public bool EliminarPropiedad(int id)
        {
            using var connection = new MySqlConnection(connectionString);
            connection.Open();
            using var command = new MySqlCommand("DELETE FROM Propiedades WHERE Id = @Id", connection);
            command.Parameters.AddWithValue("@Id", id);
            return command.ExecuteNonQuery() > 0;
        }
    }
}
